---
layout: post
title: Example post
cover: cover.jpg
date:   2013-12-09 12:00:00
categories: posts
---

## Introducing Flex, a Jekyll theme

Flex is a minimalist, responsive theme based on the website, [The Development](http://thedevelopment.co).

## Open Sourced on GitHub

Flex is open sourced on GitHub and is licensed under the [MIT License](http://opensource.org/licenses/MIT). Feel free to contribute to it anytime!
